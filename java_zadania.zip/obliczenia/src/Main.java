import java.math.BigInteger;

public class Main {
    public static void main( String[] args ) {

        int a = 28;
        int b = 23;

        int c1 = a+b;
        int c2 = a-b;
        int c3 = a*b;
        double c4 = (double)a/b;
        int c5 = a%b;

        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
        System.out.println(c4);
        System.out.println(c5);

        double nb = 9.0;
        int ng = 3;
        double root = Math.sqrt(nb);
        double power = Math.pow(nb,ng);

        System.out.println("pierwiastek: " + root);
        System.out.println("potęga: " + power);

        BigInteger k = new BigInteger("8594859348593458934582495834939458");
        BigInteger m = new BigInteger("8938423049203498102834923849234892348293");

        BigInteger suma = k.add(m);
        System.out.println(suma);

        BigInteger mno = k.multiply(m);
        System.out.println(mno);

    }
}