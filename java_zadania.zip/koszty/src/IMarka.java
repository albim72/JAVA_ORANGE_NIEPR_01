public interface IMarka {
    String samochod(String marka, String model,double poj,String rodzsiln);
}
