public interface IPojazd {

    double spalanie(double spal100);
    double kosztyprzejazdu(double spal100,int odl,double cena_l);

}
