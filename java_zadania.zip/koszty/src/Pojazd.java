public class Pojazd implements IPojazd,IMarka{

    String marka;
    String model;
    double poj;
    String rodz_silnika;

    //Void typ;

    public Pojazd( String marka, String model, double poj, String rodz_silnika ) {
        this.marka = marka;
        this.model = model;
        this.poj = poj;
        this.rodz_silnika = rodz_silnika;
        //this.typ = typ;
    }

    @Override
    public double spalanie( double spal100 ) {
        return spal100;
    }

    @Override
    public double kosztyprzejazdu( double spal100, int odl, double cena_l ) {
        return spalanie(spal100)*(odl/100)*cena_l;
    }


    @Override
    public String samochod( String marka, String model, double poj, String rodzsiln ) {
        return "Opis auta -> marka: " + this.marka + ", model: " + this.model +
                ", pojemność silnika" + String.valueOf(this.poj) +
                ", rodzaj silnika: "  + this.rodz_silnika;

    }
}
