import java.util.Scanner;

enum typ {
    SUV,
    OSOBOWY,
    ROWER
}

public class Main {
    public static void main( String[] args ) {

        Pojazd audi = new Pojazd("Audi","Q7",4.8,"diesel");
        System.out.println(audi.samochod(audi.marka, audi.model, audi.poj, audi.rodz_silnika));
        System.out.printf("Typ nadwozia: %s\n",typ.SUV);
        Scanner sc = new Scanner(System.in);
        System.out.println("Podaj spalanie w litrach na 100km: ");
        double spalanie = sc.nextDouble();
        System.out.println("Podaj odległość w km: ");
        int odl = sc.nextInt();
        System.out.println("Podaj cenę litra paliwa (zł): ");
        double cena = sc.nextDouble();

        System.out.printf("Spalanie na 100km: %.2f l",audi.spalanie(spalanie));
        System.out.printf("Koszty przejazdu: %.2f zł",audi.kosztyprzejazdu(audi.spalanie(spalanie),
                odl,cena));


    }
}