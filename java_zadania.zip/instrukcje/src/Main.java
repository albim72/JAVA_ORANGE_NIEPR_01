public class Main {
    public static void main( String[] args ) {

        int a = 10; //instrukcja wejścia, instrukcja przypisania

        System.out.println(a); //instrukcja wyjścia

        //instrukcja warunkowa

        int i = 15;
        if (i>15)
            System.out.println("i > 15");
        else if (i==15)
            System.out.println("i = 15");
        else if (i==0)
            System.out.println("i = 15");
        else
            System.out.println("i <= 15");


        //instrukcja iteracyjna
        int y = 1;
        int h = 3;
        while (y <= 4)
        {
            System.out.println("Wartość y = " + (y + h));
            y++; //y++ -> y = y+1
        }

        for (int x=2;x<=4;x+=2){
            System.out.println("wartość x: " + x);
        }

        String array[] = {"Kraków","Lublin","Wrocław","Toruń"};

        for(String x:array)
        {
            System.out.println(x);
        }

        for (int k=1;k<array.length;k+=2){
            System.out.println(array[k]);
        }

        

    }
}