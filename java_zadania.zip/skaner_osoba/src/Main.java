import java.util.Scanner;

public class Main {
    public static void main( String[] args ) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Podaj imię biegacza: ");
        String imie = sc.nextLine();
        System.out.println("Podaj nazwisko biegacza: ");
        String nazwisko = sc.nextLine();
        System.out.println("Podaj wiek biegacza: ");
        int wiek = sc.nextInt();
        System.out.println("Podaj dystans miesięczny biegacza: ");
        long dystans = sc.nextLong();
        System.out.println("Podaj wagę biegacza: ");
        double waga = sc.nextDouble();
        System.out.println("Podaj wzrost biegacza: ");
        int wzrost = sc.nextInt();

        System.out.println("Dane biegacza:");
        System.out.println("Imię: " + imie);
        System.out.println("Nazwisko: " + nazwisko);
        System.out.println("wiek: " + wiek + " lat");
        System.out.println("dystans: " + dystans + "m");
        System.out.println("waga: " + waga + "kg");
        System.out.println("wzrost: " + wzrost +"cm");
    }
}