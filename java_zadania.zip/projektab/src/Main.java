import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {
    public static void main( String[] args ) throws IOException {

        //wprowdź poprzez skaner do programu wartości a,b w typie int
        //wykonaj działanie 1 - a^b, 2 - a/b i wyświetl wyniki

        Scanner sc = new Scanner(System.in);
        System.out.println("Podaj wartość a:");
        int a = sc.nextInt();
        System.out.println("Podaj wartość b:");
        int b = sc.nextInt();

        int d1 = (int) Math.pow(a,b);
        double d2 = (double) a/b;

        System.out.println("wynik działania pierwszego: " + d1);
        System.out.println("wynik działania drugiego: " + d2);

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Podaj wartość c: ");
        int c = Integer.parseInt(br.readLine());

        System.out.println("Dodaj opis do wartości c: ");
        String opis = br.readLine();

        System.out.println("wprowadzono wartość: " + c + ", opis: " + opis);

        System.out.println("podaj wartość d: ");
        String d = br.readLine();

        System.out.println(Double.parseDouble(d)/2);



    }
}