public class Main {
    public static void main( String[] args ) {

        int dzien = 1;
        System.out.println("Podany numer dnia tygodnia: " + dzien);
        String nazwadnia;
        switch (dzien){
            case 1:
                nazwadnia = "Poniedziałek";
                break;
            case 2:
                nazwadnia = "Wtorek";
                break;
            case 3:
                nazwadnia = "Środa";
                break;
            case 4:
                nazwadnia = "Czwartek";
                break;
            case 5:
                nazwadnia = "Piątek";
                break;
            case 6:
                nazwadnia = "Sobota";
                break;
            case 7:
                nazwadnia = "Niedziela";
                break;
            default:
                nazwadnia = "błędna wartość!";
        }
        System.out.println(nazwadnia);

        //wprowadź zmienną stopien_wiel(String)
        //masz do wyboru dwie wartości: "pierwszy", "drugi"
        //wprowadź wartości parametrów a,b,oraz x (int)
        //użyj instrukcji switch-case do przypisania stosownego wykonania działania:
        //"pierwszy" -> a*x+b
        //"drugi" -> a*x^2+b*x

        String stopien_wiel = "drugi";
        int a=3, b=8, x=2;
        int wynik;
        switch (stopien_wiel){
            case "pierwszy":
                wynik = a*x+b;
                break;
            case "drugi":
                wynik = (int) (a*Math.pow(x,2)+b*x);
                break;
            default:
                System.out.println("brak wyboru stopnia wielomianu");
                wynik = 0;
                break;
        }
        System.out.println("wynik funkcji wielomian: "+ wynik);
    }
}