public class DrugaKlasa extends PierwszaKlasa{

    int c;
    public DrugaKlasa( int a, int b, int c ) {
        super(a, b);
        this.c = c;
    }

    public void wyswietl_abc(){
        System.out.printf("parametry klasy: a = %d, b = %d, c = %d\n",
                this.a,this.b,this.c);
    }

    public int sumuj(){
        return this.a+this.b+this.c;
    }
}
