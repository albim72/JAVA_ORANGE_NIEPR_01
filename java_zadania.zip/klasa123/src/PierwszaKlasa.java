public class PierwszaKlasa {
    int a;
    int b;

    public PierwszaKlasa( int a, int b ) {
        this.a = a;
        this.b = b;
    }

    public void wyswietl_ab(){
        System.out.printf("parametry klasy: a = %d, b = %d\n",this.a,this.b);
    }
}
