public class Main {
    public static void main( String[] args ) {
        System.out.printf("Struktura klas: %15s,%15s,%15s, \n\tliczba klas: \"%d\" \n",
                "PierwszaKlasa","DrugaKlasa","TrzeciaKlasa",3);
        System.out.println("Sprawdźmy klasy:");

        System.out.println("Metody klasy: PierwszaKlasa");

        PierwszaKlasa pk = new PierwszaKlasa(56,8);
        pk.wyswietl_ab();

        System.out.println("\nMetody klasy: DrugaKlasa");
        DrugaKlasa dk = new DrugaKlasa(23,6,17);
        dk.wyswietl_ab();
        dk.wyswietl_abc();
        System.out.printf("wynik sumowania a+b+c: %d",dk.sumuj());

        System.out.println("\nMetody klasy: TrzeciaKlasa");
        TrzeciaKlasa tk = new TrzeciaKlasa(4,18,9,55);
        tk.wyswietl_ab();
        tk.wyswietl_abc();
        tk.wyswietl_abcd();
        System.out.printf("wynik sumowania a+b+c+d: %d",tk.sumuj());
    }
}