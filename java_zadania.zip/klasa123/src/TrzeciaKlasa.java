public class TrzeciaKlasa extends DrugaKlasa{
    int d;
    public TrzeciaKlasa( int a, int b, int c,int d ) {
        super(a, b, c);
        this.d = d;
    }

    public void wyswietl_abcd(){
        System.out.printf("parametry klasy: a = %d, b = %d, c = %d, d = %d\n",
                this.a,this.b,this.c,this.d);
    }

    @Override
    public int sumuj() {
        return this.a+this.b+this.c+this.d;
    }

}
