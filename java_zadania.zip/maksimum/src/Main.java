public class Main {
    public static void main( String[] args ) {

        System.out.println(info());
        System.out.println("Koszt przejazdu: " + kosztprzejazdu(6.4,566,7.52) + "zł");
        int[] oceny = {125,188,110,88,158,186,2};
        int maxocena = maksimum(oceny);
        System.out.println("njwiększa wartość: " + maxocena);

        int[] odleg = {102,560,1099,200,1003 ,3,54,16};
        int maxodl = maksimum(odleg);
        System.out.println("njwiększa odległość: " + maxodl);


    }

    //stwórz metodę która zdefiniuje największą wartość ze zbioru

    public static int maksimum(int[] num){
        int maxS = num[0];

        for(int n:num)
        {
            if(n>maxS){
                maxS = n;
            }
        }
        return maxS;
    }

    public static String info(){
        return "ważna wiadomość";
    }

    public static double kosztprzejazdu(double spal, int odl, double cena_l){
        double koszt = spal*odl/100*cena_l;
        return koszt;
    }
}