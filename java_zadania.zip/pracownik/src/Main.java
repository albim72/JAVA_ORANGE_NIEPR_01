public class Main {
    public static void main( String[] args ) {

        Osoba dziadek = new Osoba("pływanie",25,"1000m 18min","Jan",
                "Kowalski","M",72,70,175);
        dziadek.infoosoba();
        System.out.printf("wiek dziadka za 10 lat: %d lat\n",dziadek.wiekza10lat());
        System.out.printf("czy dziadek jest pracownikiem: %s\n",dziadek.czypracownik());

        Pracownik dyr = new Pracownik("biegi ultra",12,"102km 18godz 34min 45s",
                "Olga","Kot","K",34,51,177,"ABC SA",6,
                "dyrektor",10200);

        dyr.infoosoba();
        dyr.infopracownik();
        dyr.infosport(2);
        dyr.ostatniaaktywnosc(125,"siła biegowa",1213);
        System.out.printf("\nwiek osoby za 10 lat: %d lat\n",dyr.wiekza10lat());
        System.out.printf("czy osoba jest pracownikiem: %s\n",dyr.czypracownik());

    }
}