public class Osoba extends Sport {

    String imie;
    String nazwisko;
    String plec;
    int wiek;
    double waga;
    int wzrost;

    public Osoba( String dysycyplina, int lataupr, String best_wynik, String imie, String nazwisko,
                  String plec, int wiek, double waga, int wzrost ) {
        super(dysycyplina, lataupr, best_wynik);
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.plec = plec;
        this.wiek = wiek;
        this.waga = waga;
        this.wzrost = wzrost;
    }

    public void infoosoba(){
        System.out.printf("Dane osoby -> imię: %s, nazwisko: %s, płeć: %s, wiek: %d\n",
                this.imie, this.nazwisko,this.plec,this.wiek);
    }

    public int wiekza10lat(){
        return this.wiek+10;
    }

    public boolean czypracownik(){
        return false;
    }
}
