public class Pracownik extends Osoba {

    String firma;
    int latapracy;
    String stanowisko;
    double wynagrodzenie;

    public Pracownik( String dysycyplina, int lataupr, String best_wynik, String imie,
                      String nazwisko, String plec, int wiek, double waga, int wzrost, String firma,
                      int latapracy, String stanowisko, double wynagrodzenie )
    {
        super(dysycyplina, lataupr, best_wynik, imie, nazwisko, plec, wiek, waga, wzrost);
        this.firma = firma;
        this.latapracy = latapracy;
        this.stanowisko = stanowisko;
        this.wynagrodzenie = wynagrodzenie;
    }

    @Override
    public boolean czypracownik() {
        return true;
    }

    public void infopracownik(){
        System.out.printf("Dane pracownika -> firma: %s, stanowisko: %s, lata pracy: %d, wynagrodzenie: %.2f zł\n",
                this.firma, this.stanowisko, this.latapracy, this.wynagrodzenie);
    }
}
