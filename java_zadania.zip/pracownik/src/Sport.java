public class Sport {

    String dysycyplina;
    int lataupr;
    String best_wynik;

    public Sport( String dysycyplina, int lataupr, String best_wynik ) {
        this.dysycyplina = dysycyplina;
        this.lataupr = lataupr;
        this.best_wynik = best_wynik;
    }

    public void infosport(int id){
        System.out.printf("Dysycyplina: %s,id:%d, lata uprawiania sportu: %d, życiówka: %s\n",
                this.dysycyplina, id, this.lataupr, this.best_wynik);
    }

    public void ostatniaaktywnosc(int czas_trwania,String rodzaj,int kcal){
        System.out.printf("Aktywność: %d min, rodzaj aktywności: %s, spalone kalorie: %d kcal",
                czas_trwania,rodzaj,kcal);
    }
}
