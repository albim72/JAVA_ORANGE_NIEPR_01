
class Pies{
    //opis stanu
    //wypisanie zmiennych opisujących przszły obiekt
    String imie;
    String rasapsa;
    int wiek;
    String kolor;

    //Konstruktor klasy


    public Pies( String imie, String rasa, int wiek, String kolor ) {
        this.imie = imie;
        this.rasapsa = rasa;
        this.wiek = wiek;
        this.kolor = kolor;
        this.info();
    }

    //opis zachowania
    public String getImie() {
        return imie;
    }

    public String getRasapsa() {
        return rasapsa;
    }

    public int getWiek() {
        return wiek;
    }

    public String getKolor() {
        return kolor;
    }

    public void info(){
        System.out.println("Tworzenie nowego psa");
    }

    @Override
    public String toString() {
        return "Pies wabi się: " + this.getImie() + ", rasa: " + this.getRasapsa() +
                ", wiek: " + this.getWiek() + ", umaszczenie: " + this.getKolor();
    }
}


public class Main {
    public static void main( String[] args ) {
        Pies buldi = new Pies("Ludvik", "buldog angielski", 1, "biały z rudym");
        System.out.println(buldi.toString());

        Pies cane = new Pies("Olo","Cane Corso",4,"szary");
        System.out.println(cane.toString());

    }
}