public abstract class Figura {
    protected double a;
    protected double b;

    public Figura( double a ) {
        this.a = a;
        this.nowa();
    }

    public Figura( double a, double b ) {
        this.a = a;
        this.b = b;
        this.nowa();
    }

    public void nowa(){
        System.out.println("nowa figura została utworzona!");
    }
    public abstract double policzpole();
}
