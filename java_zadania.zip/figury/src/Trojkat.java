public class Trojkat extends Figura {
    public Trojkat( double a, double b ) {
        super(a, b);
    }

    @Override
    public double policzpole() {
        return this.a*this.b/2;
    }
}
