public class Kwadrat extends Figura {
    public Kwadrat( double a ) {
        super(a);
    }

    @Override
    public double policzpole() {
        return this.a*this.a;
    }
}
