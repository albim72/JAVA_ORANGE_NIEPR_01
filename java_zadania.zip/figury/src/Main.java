public class Main {
    public static void main( String[] args ) {

        Prostokat pr = new Prostokat(4.6,7.2);
        System.out.printf("pole prostokąta wynosi %.2f cm2\n",pr.policzpole());

        Trojkat tr = new Trojkat(4.5,6.6);
        System.out.printf("pole trójkąta wynosi %.2f cm2\n",tr.policzpole());

        Trapez trp = new Trapez(6.4,5.2,4.6);
        System.out.printf("pole trapezu wynosi %.2f cm2\n",trp.policzpole());

        Kolo kl = new Kolo(5.5);
        System.out.printf("pole koła wynosi %.2f cm2\n",kl.policzpole());

        Kwadrat kw = new Kwadrat(6);
        System.out.printf("pole kwadratu wynosi %.2f cm2\n",kw.policzpole());
    }
}