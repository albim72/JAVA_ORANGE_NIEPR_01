public class Trapez extends Figura{
    double h;
    public Trapez( double a, double b, double h ) {
        super(a, b);
        this.h=h;
    }

    @Override
    public double policzpole() {
        return (this.a+this.b)*this.h/2;
    }
}
