public class Kolo extends Figura{

    public Kolo( double a ) {
        super(a);
    }

    @Override
    public double policzpole() {
        return Math.PI*this.a*this.a;
    }
}
