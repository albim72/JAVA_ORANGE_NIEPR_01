public class Main {
    public static void main( String[] args ) {
        Osoba os1 = new Osoba("Olga","Kot",30,"Kraków");
        os1.print_osoba("kobieta");

        Osoba os2 = new Osoba("Artur","Nowak",43,"Tarnów");
        os1.print_osoba("mężczyzna");

    }
}