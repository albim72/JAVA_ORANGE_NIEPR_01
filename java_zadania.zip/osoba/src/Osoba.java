public class Osoba {
    String imie;
    String nazwisko;
    int wiek;
    String miasto;

    public Osoba( String imie, String nazwisko, int wiek, String miasto ) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.wiek = wiek;
        this.miasto = miasto;
    }

    public void print_osoba(String plec){
        System.out.println("Dane osoby - imię: " + this.imie + ", nazwisko: " + this.nazwisko
               + ", miasto: " + this.miasto + ", płeć: " + plec);
    }
}
