public class Main {
    public static void main( String[] args ) {

        System.out.println("Hello world!"); //standard
        //komentarz jednoliniowy
        /*
        koentarz wiele linii
        l1
        l2

         */

        /**
         * komentarz dokumentacyjny
         * abc
         *
         */
        System.out.println("mój komunikat");
        //sout
        System.out.println("skrót sout");

        System.out.println('a' + 'A');
        System.out.println("a" + "A");
        System.out.println(1 + 2);
        //CTRL+D  - duplikacja linii
        System.out.println(1.0 + 2.0);
        System.out.println(true);
        System.out.println("cudzysłów: \"");

        int liczba1 = 5;
        int liczba2 = liczba1 * 2;
        System.out.println(liczba1 * liczba2);

        double liczba3 = 7.888;
        double wynik = liczba1 * liczba3;
        System.out.println(wynik);

        double liczba4 = 8;
        System.out.println(liczba4);

        //int liczba5 = 5.5;

    }
}