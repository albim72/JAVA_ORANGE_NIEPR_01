public class Main {
    public static void main( String[] args ) {

        //sprawdź parzystość wartości x
        int x = 5;
        if (x % 2 == 0) {
            System.out.println("Liczba x jest parzysta");
        } else {
            System.out.println("Liczba x jest nieparzysta");
        }

        /*sprawdź w jakim przedziale mieści się wiek osoby
        wypisz komunikaty w zależności od przedziału
        wiek poniżej 2 lat - niemowlak
        od 3 - 12 - dziecko
        13 - 18 młodzież
        19 - 29 młodzi
        30 - 65 siła wieku
        powyżej 65 - senior

        if, else if, else

         */

        int wiek = 3;

        if(wiek <= 0){
            System.out.println("nie podawaj wieku ujemnego!");
        }else{
            if (wiek <= 2) {
                System.out.println("niemowlak");
                //System.out.println(wiek + "lat");
            } else if (wiek <= 12) {
                System.out.println("dziecko");
                //System.out.println(wiek + "lat");
            } else if (wiek <= 18) {
                System.out.println("młodzież");
                //System.out.println(wiek + "lat");
            } else if (wiek <= 29) {
                System.out.println("młodzi");
                //System.out.println(wiek + "lat");
            } else if (wiek <= 65) {
                System.out.println("siła wieku");
                //System.out.println(wiek + "lat");
            } else if (wiek > 65) {
                System.out.println("senior");
                //System.out.println(wiek + "lat");
            }else {
                System.out.println("brak danych");
            }
            System.out.println(wiek + "lat");
        }





    }

}
